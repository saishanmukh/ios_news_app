//
//  CategoriesViewController.swift
//  News_App_iOS
//
//  Created by student on 4/6/22.
//

import UIKit

class CategoriesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    let categories = ["headlines", "sports", "technology"]
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categories.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = categoryCollectionView.dequeueReusableCell(withReuseIdentifier: "category", for: indexPath) as! CategoryCollectionViewCell
        
        cell.categoryName.text = categories[indexPath.row]
//        cell.categoryName.rowWidth = UITextView.automaticDimension
        return cell
        
        
    }
    

    @IBOutlet weak var headlines: UITableView!

//    categoryButton
    @IBOutlet weak var categoryCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        categoryCollectionView.delegate = self
        categoryCollectionView.dataSource = self
        

        // Do any additional setup after loading the view.
    }
    


}
