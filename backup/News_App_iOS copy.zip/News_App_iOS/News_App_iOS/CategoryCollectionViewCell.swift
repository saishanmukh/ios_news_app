//
//  CategoryCollectionViewCell.swift
//  News_App_iOS
//
//  Created by student on 5/1/22.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    

    @IBOutlet weak var categoryName: UITextView!
    
    
}
