//
//  RegisterViewController.swift
//  News_App_iOS
//
//  Created by student on 4/5/22.
//

import UIKit
import Firebase
import FirebaseAnalytics
//FIRDatabaseReference
//import SQLite3
//
//var db: OpaquePointer?

class RegisterViewController: UIViewController {

    @IBOutlet weak var firstName: UITextField!
    
    @IBOutlet weak var lastName: UITextField!
    
    @IBOutlet weak var emailId: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var confirmPassword: UITextField!
    
    @IBAction func registerButtonAction(_ sender: Any) {
        var ref: DatabaseReference!

        ref = Database.database().reference()
//        let ref = FirebaseApp
//        Database.database().reference()
        
        

    }
    override func viewDidLoad() {
        super.viewDidLoad()
//        let fileURL = URL(fileURLWithPath: "/Users/student/Documents/project_news_app/ios_news_app/News_App_iOS/News_App_iOS/NewsApp.sqlite")
//
//
//        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
//            print("error opening database")
//        }
//        if sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS Users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)", nil, nil, nil) != SQLITE_OK {
//            let errmsg = String(cString: sqlite3_errmsg(db)!)
//            print("error creating table: \(errmsg)")
//        }

        // Do any additional setup after loading the view.
    }

}
