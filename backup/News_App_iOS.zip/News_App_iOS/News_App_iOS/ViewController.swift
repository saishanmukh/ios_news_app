//
//  ViewController.swift
//  News_App_iOS
//
//  Created by Nagarushyanth Tummala on 4/4/22.
//

import UIKit
//import SQLite3

class ViewController: UIViewController {
       

    @IBOutlet weak var loginId: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    
    @IBAction func loginButtonAction(_ sender: Any) {
    }
    
    @IBAction func signupButtonAction(_ sender: Any) {
    }
    
    override func viewDidLoad() {
      super.viewDidLoad()
    }

}

