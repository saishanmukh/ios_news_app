//
//  CategoriesViewController.swift
//  News_App_iOS
//
//  Created by student on 4/6/22.
//

import UIKit

class CategoriesViewController: UIViewController {

    @IBOutlet weak var headlines: UITableView!
    @IBAction func searchButton(_ sender: Any) {
    }
    
    @IBOutlet weak var categoryName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
