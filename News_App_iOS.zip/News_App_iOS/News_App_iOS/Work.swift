//
//  Work.swift
//  News_App_iOS
//
//  Created by student on 4/30/22.
//

import UIKit

struct Work {
  let title: String
  let image: UIImage
  let info: String
  var isExpanded: Bool
}
